# QA Wrap for Opera

Chromium. Installs from the Chrome Web Store once "Install Chrome extensions" is enabled, or from Opera add-ons, which reviews separately. Opera has no side panel API, so the float window is used.

## Built from

One source tree. Every content script, every export and the whole ISTQB model
are identical to the Chrome build; only the manifest differs.

- removed sidePanel — Opera does not implement them, and a manifest naming one is rejected at install
- dropped the side_panel key — no chrome.sidePanel in this browser
- store build: dropped the manifest key — Edge and Opera stores refuse it and assign their own id

## Loading it

`opera://extensions` → Developer mode → Load unpacked → pick this folder.

## What is unavailable here

- `sidePanel`

The features that need these are disabled in the interface and say which browser they need, rather than failing when pressed. See `core/capabilities.js`.
