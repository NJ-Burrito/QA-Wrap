# QA Wrap for Opera

Chromium. Installs from the Chrome Web Store once "Install Chrome extensions" is enabled, or from Opera add-ons, which reviews separately.

## Built from

One source tree. Every content script, every export and the whole ISTQB model
are identical to the Chrome build; only the manifest differs.

- store build: dropped the manifest key — Edge and Opera stores refuse it and assign their own id

## Loading it

`opera://extensions` → Developer mode → Load unpacked → pick this folder.

## What is unavailable here

Nothing. This build has the full surface.
